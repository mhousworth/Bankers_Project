import java.util.HashMap;

public class Banker {

    //Resource Array Class
    private class Resources {
        int[] arr = {0, 0, 0};

        //Constructors
        Resources() {
        }
        Resources(Resources R) {
            this.arr[0] = R.arr[0];
            this.arr[1] = R.arr[1];
            this.arr[2] = R.arr[2];
        }

        Resources(int R0, int R1, int R2) {
            arr[0] = R0;
            arr[1] = R1;
            arr[2] = R2;
        }

        int get_R(int r) {
            return arr[r];
        }

        void set_R(int r, int i) {
            arr[r] = i;
        }
    }

    private class Process {
        Resources max;      //Resources required to run to completion
        Resources alloc;    //Resources currently allocated to the process
        boolean complete;

        Process() {
            complete = false;
        }
        Process(Process P) {
            this.max = new Resources(P.max);
            this.alloc = new Resources(P.alloc);
            this.complete = P.complete;
        }
        Process(int r0,int r1, int r2) {
            max = new Resources(r0,r1,r2);
            alloc = new Resources(0,0,0);
            complete = false;
        }

        int[] getMax() {
            int[] arr = new int[]{max.get_R(0), max.get_R(1), max.get_R(2)};
            return arr;
        }

        int[] getAlloc() {
            int[] arr = {alloc.get_R(0), alloc.get_R(1), alloc.get_R(2)};
            return arr;
        }

        void setAlloc(int r0, int r1, int r2){
            alloc.set_R(0,r0);
            alloc.set_R(1,r1);
            alloc.set_R(2,r2);
        }

        //Returns array of int, representing resources the process still needs allocated
        int[] need() {
            int[] arr = {max.get_R(0) - alloc.get_R(0), max.get_R(1) - alloc.get_R(1), max.get_R(2) - alloc.get_R(2)};
            return arr;
        }

        //Returns true if Resource allocation is
        boolean canRun() {
            if(complete) {
                //if process already completed it cannot run again
                return false;
            }
            int[] need = this.need();
            //if needed resources are all zero, process can run to completion.
            return (need[0] == 0 && need[1] == 0 && need[2] == 0);
        }

        void run() {
            if(canRun())
                complete = true;
        }
    }

    //Total System Resources
    private Resources system_total;
    //Allocated System Resources
    private Resources system_alloc;
    //Array of Processes
    private HashMap<Integer,Process> processes;

    Banker(int r0, int r1, int r2) {
        system_total = new Resources(r0,r1,r2);
        system_alloc = new Resources(0,0,0);
        processes = new HashMap<Integer, Process>();
    }

    Banker(Banker B) {
        this.system_total = new Resources(B.system_total);
        this.system_alloc = new Resources(B.system_alloc);
        this.processes = new HashMap<Integer, Process>();

        for (int k : B.processes.keySet()) {
            this.processes.put(k, new Process(B.processes.get(k)));
        }
    }

    //Returns an array of available system resources
    int[] get_available(){
        int[] arr = {system_total.get_R(0)-system_alloc.get_R(0),system_total.get_R(1)-system_alloc.get_R(1),system_total.get_R(2)-system_alloc.get_R(2)};
        return arr;
    }

    //Returns true if it creates a process
    public boolean create_process(int id, int r0, int r1, int r2) {
        int[] total = {system_total.get_R(0),system_total.get_R(1),system_total.get_R(2)};

        //Check if the total of a system resource is less than the max of a process
        if (total[0] < r0 | total[1] < r1 | total[2] < r2)
            return false;

        Process p = new Process(r0, r1, r2);
        processes.put(id, p);

        return true;
    }

    //returns true if process has completed and terminated
    public boolean get_process_status(int id){
        return processes.get(id).complete;
    }

    //id = processes key | type = 0:getAlloc() 1:getMax() 2:need()
    public int[] get_process_info(int id, int type) {
        if (type == 0)
            return processes.get(id).getAlloc();
        else if (type == 1)
            return processes.get(id).getMax();
        else if (type == 2)
            return processes.get(id).need();
        else {
            return new int[]{0,0,0};
        }
    }

    //Recursive driver, deep copy of banker's info to test end state of allocation
    private boolean validate_driver(int id, int r0, int r1, int r2) {
        //Deep Copy this Banker
        Banker B = new Banker(this);
        //Banker B will validate by attempting to recursively complete all Processes
        return B.validate(id, r0, r1, r2);
    }

    //Returns true if an allocation leaves system in a safe state
    private boolean validate(int id, int r0, int r1, int r2) {
        //Get available system resources
        int[] avail = get_available();

        //Check if any available resource is less than requested, if so return false
        if (avail[0] < r0 | avail[1] < r1 | avail[2] < r2)
            return false;

        //Get original system and process allocation
        Resources sys_alloc = new Resources(system_alloc);
        int[] p_ori = processes.get(id).getAlloc();

        //Set new allocations after request
        processes.get(id).setAlloc(p_ori[0] + r0, p_ori[1] + r1, p_ori[2] + r2);
        system_alloc.set_R(0, sys_alloc.get_R(0) + r0);
        system_alloc.set_R(1, sys_alloc.get_R(1) + r1);
        system_alloc.set_R(2, sys_alloc.get_R(2) + r2);

        //create flag, set to false
        boolean f = false;

        //If we can run process, run and release
        if(processes.get(id).canRun()){
            processes.get(id).run();
            release(id);
        }

        //For any process that hasn't completed
        for (int k : processes.keySet()) {
            if (!get_process_status(k)) {
                //Get what resources it needs
                int[] need = processes.get(k).need();

                //Validate, checks if it can allocate and run
                f = validate(k, need[0], need[1], need[2]);

                //If validate returns true, all processes were found to have run
                if(f)
                    return f;
            }
        }

        //If any process has not completed
        for (int k : processes.keySet()) {
            if (!get_process_status(k)) {
                return false;
            }
        }

        //If all processes have completed, still in a safe state
        return true;
    }

    //Process requests resources. If possible and still in a safe state, then resources are allocated
    public boolean request(int id, int r0, int r1, int r2){
        //Get needed resources
        int[] need = processes.get(id).need();

        //Check if process is requesting more than its max, return false
        if (need[0] < r0 | need[1] < r1 | need[2] < r2)
            return false;

        if(validate_driver(id, r0, r1, r2)) {
            //Get original process allocation
            int[] p_ori = processes.get(id).getAlloc();

            //Set process and system resource allocation
            processes.get(id).setAlloc(p_ori[0] + r0, p_ori[1] + r1, p_ori[2] + r2);
            system_alloc.set_R(0, system_alloc.get_R(0) + r0);
            system_alloc.set_R(1, system_alloc.get_R(1) + r1);
            system_alloc.set_R(2, system_alloc.get_R(2) + r2);

            return true;
        }

        return false;
    }

    //Process releases its resources, returned to system
    public void release(int id) {
        int[] released = processes.get(id).getAlloc();
        int[] current = {system_alloc.get_R(0),system_alloc.get_R(1),system_alloc.get_R(2)};

        //Set process resources to 0
        processes.get(id).setAlloc(0,0,0);

        system_alloc.set_R(0,current[0] - released[0]);
        system_alloc.set_R(1,current[1] - released[1]);
        system_alloc.set_R(2,current[2] - released[2]);
    }

    public boolean can_execute(int id) {
        return processes.get(id).canRun();
    }

    //Returns true if process runs
    public boolean execute(int id) {
        if (processes.get(id).canRun()){
            processes.get(id).run();
            return true;
        }
        else
            return false;
    }

}
