import java.util.HashMap;

public class Banker {

    //Resource Array Class
    private class Resources {
        int[] resources;

        //Constructors
        Resources() { }

        Resources(Resources R) { this.resources = R.resources.clone(); }

        Resources(int n) {
            resources = new int[n];
            for (int i = 0; i < n; i++){
                resources[i] = 0;
            }
        }

        Resources(int[] arr) { resources = arr.clone(); }

        //Getter
        int[] get_R() {
            return resources.clone();
        }

        //Setter
        void set_R(int[] arr) {
            resources = arr.clone();
        }
    }

    private class Process {
        Resources max;      //Resources required to run to completion
        Resources alloc;    //Resources currently allocated to the process
        boolean complete;

        Process() {
            complete = false;
        }

        Process(Process P) {
            this.max = new Resources(P.max);
            this.alloc = new Resources(P.alloc);
            this.complete = P.complete;
        }

        Process(int[] arr) {
            max = new Resources(arr);
            alloc = new Resources(arr.length);
            complete = false;
        }

        int[] getMax() {
            return max.resources.clone();
        }

        int[] getAlloc() {
            return alloc.resources.clone();
        }

        void setAlloc(int[] arr){
            alloc.resources = arr.clone();
        }

        //Returns array of int, representing resources the process still needs allocated
        int[] need() {
            int[] arr = new int[max.resources.length];
            for(int i = 0; i < arr.length; i++){
                arr[i] = max.resources[i] - alloc.resources[i];
            }
            return arr.clone();
        }

        //Returns true if Resource allocation is
        boolean canRun() {
            if(complete) {
                //if process already completed it cannot run again
                return false;
            }

            //if needed resources are all zero, return true
            int[] need = this.need();
            for (int i = 0; i < need.length; i++) {
                //If one is found to not be zero
                if (need[i] != 0)
                    return false;
            }
            return true;
        }

        void run() {
            if(canRun())
                complete = true;
        }
    }

    private int RESOURCES;
    //Total System Resources
    private Resources system_total;
    //Allocated System Resources
    private Resources system_alloc;
    //Array of Processes
    private HashMap<Integer,Process> processes;

    Banker(int R, int[] arr) {
        RESOURCES = R;
        if(arr.length == R)
            system_total = new Resources(arr);
        system_alloc = new Resources(R);
        processes = new HashMap<Integer, Process>();
    }

    Banker(Banker B) {
        this.RESOURCES = B.RESOURCES;
        this.system_total = new Resources(B.system_total);
        this.system_alloc = new Resources(B.system_alloc);
        this.processes = new HashMap<Integer, Process>();

        for (int k : B.processes.keySet()) {
            this.processes.put(k, new Process(B.processes.get(k)));
        }
    }

    int get_RESOURCES() { return RESOURCES; }

    //Returns an array of available system resources
    int[] get_available(){
        int[] arr = new int[system_total.resources.length];
        for(int i = 0; i < arr.length; i++){
            arr[i] = system_total.resources[i] - system_alloc.resources[i];
        }
        return arr.clone();
    }

    //Returns true if it creates a process
    public boolean create_process(int id, int[] arr) {
        int[] total = system_total.get_R();

        //Check if the total of a system resource is less than the max of a process
        for (int i = 0; i < total.length; i++) {
            if(total[i] < arr[i])
                return false;
        }

        Process p = new Process(arr);
        processes.put(id, p);

        return true;
    }

    //returns true if process has completed and terminated
    public boolean get_process_status(int id){
        return processes.get(id).complete;
    }

    //id = processes key | type = 0:getAlloc() 1:getMax() 2:need()
    public int[] get_process_info(int id, int type) {
        if (type == 0)
            return processes.get(id).getAlloc();
        else if (type == 1)
            return processes.get(id).getMax();
        else if (type == 2)
            return processes.get(id).need();
        else {
            return new int[]{0,0,0};
        }
    }

    //Recursive driver, deep copy of banker's info to test end state of allocation
    private boolean validate_driver(int id, int[] arr) {
        //Deep Copy this Banker
        Banker B = new Banker(this);
        //Banker B will validate by attempting to recursively complete all Processes
        return B.validate(id, arr.clone());
    }

    //Returns true if an allocation leaves system in a safe state
    private boolean validate(int id, int[] arr) {
        //Get available system resources
        int[] avail = get_available();

        //Check if any available resource is less than requested, if so return false
        for (int i = 0; i < avail.length; i++) {
            if(avail[i] < arr[i])
                return false;
        }

        //Get original system and process allocation
        int[] sys_alloc = system_alloc.get_R();
        int[] p_ori = processes.get(id).getAlloc();

        int[] alloc_new = new int[sys_alloc.length];
        int[] p_new = new int[p_ori.length];

        //Set new allocations after request
        for (int i = 0; i < arr.length; i++) {
            p_new[i] = (p_ori[i] + arr[i]);
            alloc_new[i] = (sys_alloc[i] + arr[i]);
        }
        processes.get(id).setAlloc(p_new);
        system_alloc.set_R(alloc_new);


        //create flag, set to false
        boolean f = false;

        //If we can run process, run and release
        if(processes.get(id).canRun()){
            processes.get(id).run();
            release(id);
        }

        //For any process that hasn't completed
        for (int k : processes.keySet()) {
            if (!get_process_status(k)) {
                //Get what resources it needs
                int[] need = processes.get(k).need();

                //Validate, checks if it can allocate and run
                f = validate(k, need);

                //If validate returns true, all processes were found to have run
                if(f)
                    return f;
            }
        }

        processes.get(id).setAlloc(p_ori);
        system_alloc.set_R(sys_alloc);

        //If any process has not completed
        for (int k : processes.keySet()) {
            if (!get_process_status(k)) {
                return false;
            }
        }

        //If all processes have completed, still in a safe state
        return true;
    }

    //Process requests resources. If possible and still in a safe state, then resources are allocated
    public boolean request(int id, int[] arr){
        if (arr.length != RESOURCES)
            return false;

        //Get needed resources
        int[] need = processes.get(id).need();

        //Check if process is requesting more than its max, return false
        for (int i = 0; i < arr.length; i++) {
            if(need[i] < arr[i])
                return false;
        }

        if(validate_driver(id, arr)) {
            //Get original process allocation
            int[] p_ori = processes.get(id).getAlloc();
            int[] sys_alloc = system_alloc.get_R();

            //Set process and system resource allocation
            for (int i = 0; i < arr.length; i++) {
                p_ori[i] = (p_ori[i] + arr[i]);
                sys_alloc[i] = (sys_alloc[i] + arr[i]);
            }
            processes.get(id).setAlloc(p_ori);
            system_alloc.set_R(sys_alloc);

            return true;
        }

        return false;
    }

    //Process releases its resources, returned to system
    public void release(int id) {
        int[] released = processes.get(id).getAlloc();
        int[] current = system_alloc.get_R();
        int[] zero = new int[current.length];

        //Set process resources to 0 and reduces sys alloc by released
        for (int i = 0; i < current.length; i++) {
            zero[i] = 0;
            current[i] = (current[i] - released[i]);
        }

        processes.get(id).setAlloc(zero);
        system_alloc.set_R(current);
    }

    public boolean can_execute(int id) {
        return processes.get(id).canRun();
    }

    //Returns true if process runs
    public boolean execute(int id) {
        if (processes.get(id).canRun()){
            processes.get(id).run();
            return true;
        }
        else
            return false;
    }

}
