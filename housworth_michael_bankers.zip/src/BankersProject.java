import java.util.Scanner;

// MAIN FUNCTION FILE


public class BankersProject {

    //Main Menu system
    public static void main(String[] args){

        Scanner keyboard = new Scanner(System.in);
        int input;

        do {
            System.out.println("====== MAIN MENU ======");
            System.out.println("Choose from the following: 1 - Interactive | 2 - Simulation | 0 - Exit");

            input = keyboard.nextInt();

            if(input == 1){
                System.out.println("====== INTERACTIVE MODE ======");
                System.out.println("Choose from the following: 1 - Start from Scratch | 2 - Load preset process config from file | 0 - Exit");
                input = keyboard.nextInt();
                if(input == 1) {
                    Interactive.start_scratch();
                }
                else if(input == 2) {
                    Interactive.start_fromfile();
                }
                continue;
            }
            else if(input == 2) {
                System.out.println("====== SIMULATION MODE ======");
                System.out.println("Choose from the following: 1 - Start sim with random1 config | 2 - Load preset process config from file | 0 - Exit");
                input = keyboard.nextInt();
                if(input == 1) {
                    Simulation.start_sim_rand();
                }
                else if(input == 2) {
                    Simulation.start_sim_fromfile();
                }
                continue;
            }
            else if(input == 0)
                System.out.println("Exiting...");
            else
                System.out.println("Invalid Input");
        }while (input != 0);
    }
}
