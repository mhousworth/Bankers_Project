import java.util.Random;
import java.lang.Runnable;
import java.util.concurrent.Semaphore;

public class Customer implements Runnable{

    Semaphore sem;
    Teller T;
    int id;
    Random rnd;
    int count;
    boolean max;

    Customer(Semaphore s,Teller t, int i) {
        sem = s;
        T = t;
        id = i;
        rnd = new Random();
        count = 0;
        max = false;
    }

    public void set_max(int r0, int r1, int r2) {
        max = true;
        T.B.create_process(id,r0,r1,r2);
        T.pid.add(id);
    }

    public void set_alloc(int r0, int r1, int r2) {
        T.B.request(id,r0,r1,r2);
    }

    @Override
    public void run() {

        try{
            sem.acquire();

            if (!max) {
                //Create process and set max in system/bank
                while(!T.B.create_process(id,rnd.nextInt(9),rnd.nextInt(9),rnd.nextInt(9)));
                T.pid.add(id);
            }

            sem.release();
        }catch (Exception e){
            System.out.println(e.toString());
        }

        try{
            Thread.sleep(rnd.nextInt(8000) % 2000);
        }catch (Exception e){
            System.out.println(e.toString());
        }

        do{
            //if looped less than 10 time
            if (count < 10) {
                try {
                    sem.acquire();

                    //make random requests
                    T.request(id, rnd.nextInt(3), rnd.nextInt(3), rnd.nextInt(3));

                    sem.release();
                } catch (Exception e) {
                    System.out.println(e.toString());
                }
            }
            else {
                //request it's needed resources
                int[] need = T.B.get_process_info(id, 2);
                T.request(id,need[0],need[1],need[2]);
            }

            count++;

            try{
                Thread.sleep(rnd.nextInt(8000) % 2000);
            }catch (Exception e){
                System.out.println(e.toString());
            }

            //If process can execute, does so
            if(T.B.can_execute(id)){
                try {
                    sem.acquire();

                    T.execute(id);

                    sem.release();
                } catch (Exception e) {
                    System.out.println(e.toString());
                }
            }
        }while(!T.B.get_process_status(id));
    }
}
