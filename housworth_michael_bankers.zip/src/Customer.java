import java.util.Random;
import java.lang.Runnable;
import java.util.concurrent.Semaphore;

public class Customer implements Runnable{

    Semaphore sem;
    Teller T;
    int id;
    Random rnd;
    int count;
    boolean max;

    Customer(Semaphore s,Teller t, int i) {
        sem = s;
        T = t;
        id = i;
        rnd = new Random();
        count = 0;
        max = false;
    }

    public void set_max(int[] max) {
        T.B.create_process(id,max);
        T.pid.add(id);
    }

    public void set_alloc(int[] alloc) {
        T.B.request(id,alloc);
    }

    @Override
    public void run() {

        try{
            sem.acquire();

            //if max is true, customer already associated with an existing process
            if (!max) {
                //Create process and set max in system/bank
                int[] max = new int[T.B.get_RESOURCES()];
                do{
                    for (int i = 0; i < T.B.get_RESOURCES(); i++) { max[i] = rnd.nextInt(9); }
                } while(!T.B.create_process(id,max));
                T.pid.add(id);
            }

            sem.release();
        }catch (Exception e){
            System.out.println(e.toString());
        }

        try{
            Thread.sleep(rnd.nextInt(8000) % 2000);
        }catch (Exception e){
            System.out.println(e.toString());
        }

        do{
            //if looped less than 10 time, safe to adjust
            if (count < 10) {
                try {
                    sem.acquire();

                    //make random request
                    int[] req = new int[T.B.get_RESOURCES()];
                    for (int i = 0; i < T.B.get_RESOURCES(); i++) { req[i] = rnd.nextInt(2); }
                    T.request(id,req);

                    sem.release();
                } catch (Exception e) {
                    System.out.println(e.toString());
                }
            }
            else {
                //simply request it's needed resources after looping enough times
                int[] need = T.B.get_process_info(id, 2);
                T.request(id,need);
            }

            count++;

            try{
                Thread.sleep(rnd.nextInt(8000) % 2000);
            }catch (Exception e){
                System.out.println(e.toString());
            }

            //If process can execute, does so
            if(T.B.can_execute(id)){
                try {
                    sem.acquire();

                    T.execute(id);

                    sem.release();
                } catch (Exception e) {
                    System.out.println(e.toString());
                }
            }
        }while(!T.B.get_process_status(id));
    }
}
