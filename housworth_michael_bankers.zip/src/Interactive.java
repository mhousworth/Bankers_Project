import java.io.File;
import java.util.Scanner;

// Interactive State with 2 start options

public class Interactive {

    //Starts interactive menu with no existing
    static void start_scratch() {
        Scanner keyboard = new Scanner(System.in);

        System.out.println("Set Total Resources of System");

        System.out.print("Enter Resource #0: ");
        int r0 = keyboard.nextInt();
        System.out.print("Enter Resource #1: ");
        int r1 = keyboard.nextInt();
        System.out.print("Enter Resource #2: ");
        int r2 = keyboard.nextInt();

        Banker B = new Banker(r0,r1,r2);
        Teller T = new Teller(B);

        do{
            T.print_instruct();
        }while(T.get_instruct());
    }

    static void start_fromfile() {
        File f = new File("src/Config1.txt");
        Teller T = new Teller();
        String str = "";

        try{
            Scanner file_reader = new Scanner(f);

            if(f.exists()) {
                while(file_reader.hasNextLine()){
                    str = file_reader.next();

                    if(str.contains("system_total")){
                        int[] sys_total = {file_reader.nextInt(), file_reader.nextInt(), file_reader.nextInt()};
                        T.B = new Banker(sys_total[0],sys_total[1],sys_total[2]);
                    }
                    else if(str.contains("process")){
                        int id = file_reader.nextInt();
                        int[] max;
                        int[] alloc;

                        str = file_reader.next();
                        if(str.contains("max")) {
                            max = new int[]{file_reader.nextInt(), file_reader.nextInt(), file_reader.nextInt()};
                            T.B.create_process(id,max[0],max[1],max[2]);
                            T.pid.add(id);
                        }

                        str = file_reader.next();
                        if(str.contains("alloc")) {
                            alloc = new int[]{file_reader.nextInt(), file_reader.nextInt(), file_reader.nextInt()};
                            T.B.request(id,alloc[0],alloc[1],alloc[2]);
                        }
                    }
                }
            }
        }catch(Exception e){
            System.out.println(e.toString());
        }

        do{
            T.print_instruct();
        }while(T.get_instruct());
    }

};

