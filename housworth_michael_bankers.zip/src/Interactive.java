import java.io.File;
import java.util.Scanner;

// Interactive State with 2 start options

public class Interactive {

    //Starts interactive menu with no existing
    static void start_scratch() {
        Scanner keyboard = new Scanner(System.in);

        System.out.println("Set Number of Total Resources of System: ");
        int R;
        do {
            R = keyboard.nextInt();
            if(R < 0)
                System.out.println("INVALID INPUT: Input must be greater than 0");
        }while (R < 0);

        System.out.print("Set Total Resources, Enter: ");
        for (int i = 0; i < R; i++) System.out.printf("R%d ", i);
        System.out.println("");

        int[] total = new int[R];
        for (int i = 0; i < R; i++) {
            if(keyboard.hasNextInt()){
                total[i] = keyboard.nextInt();
            }
            else
                System.out.printf("INVALID INPUT: Require set of %d integers", R);
        }

        Banker B = new Banker(R, total);
        Teller T = new Teller(B);

        do{
            T.print_instruct();
        }while(T.get_instruct());
    }

    static void start_fromfile() {
        // src/config1.txt   src/StallingsFig6-7.txt   src/Silberschatz8-6-3-3.txt
        File f = new File("src/config1.txt");

        int num_rec = 3;
        Teller T = new Teller();
        String str = "";

        try{
            Scanner file_reader = new Scanner(f);

            if(f.exists()) {
                while(file_reader.hasNextLine()){
                    str = file_reader.next();

                    if(str.contains("num_resources")){
                        num_rec = file_reader.nextInt();
                    }
                    else if(str.contains("system_total")){
                        int[] sys_total = new int[num_rec];
                        for (int i = 0; i < num_rec; i++) sys_total[i] = file_reader.nextInt();
                        T.B = new Banker(num_rec, sys_total);
                    }
                    else if(str.contains("process")){
                        int id = file_reader.nextInt();
                        int[] max;
                        int[] alloc;

                        str = file_reader.next();
                        if(str.contains("max")) {
                            max = new int[num_rec];
                            for (int i = 0; i < num_rec; i++) max[i] = file_reader.nextInt();
                            T.B.create_process(id,max);
                            T.pid.add(id);
                        }

                        str = file_reader.next();
                        if(str.contains("alloc")) {
                            alloc = new int[num_rec];
                            for (int i = 0; i < num_rec; i++) alloc[i] = file_reader.nextInt();
                            T.B.request(id,alloc);
                        }
                    }
                }
            }
        }catch(Exception e){
            System.out.println(e.toString());
        }

        do{
            T.print_process_table();
            T.print_instruct();
        }while(T.get_instruct());
    }

};

