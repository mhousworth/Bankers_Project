import java.io.File;
import java.util.Random;
import java.util.Scanner;
import java.util.concurrent.Semaphore;
import java.util.ArrayList;

public class Simulation {

    static void start_sim_rand() {
        Semaphore sem = new Semaphore(1);
        Random rnd = new Random();
        Teller T = new Teller();
        T.B = new Banker((rnd.nextInt(15) + 5),(rnd.nextInt(15) + 5),(rnd.nextInt(15) + 5));


        int p = (rnd.nextInt(5) + 3);

        ArrayList<Thread> customers = new ArrayList<Thread>();

        for(int i = 0; i < p; i++) {
            Thread t = new Thread(new Customer(sem,T,i));
            t.start();
            customers.add(t);
        }

        for(Thread t : customers) {
            try{
                t.join();
            }catch (Exception e){
                System.out.println(e.toString());
            }

        }

        System.out.println("Exiting Simulation...");
    }

    static void start_sim_fromfile() {
        Semaphore sem = new Semaphore(1);
        Random rnd = new Random();
        Teller T = new Teller();

        ArrayList<Thread> customers = new ArrayList<Thread>();

        File f = new File("src/StallingsFig6-7.txt");
        String str = "";

        try{
            Scanner file_reader = new Scanner(f);

            if(f.exists()) {
                while(file_reader.hasNextLine()){
                    str = file_reader.next();

                    if(str.contains("system_total")){
                        int[] sys_total = {file_reader.nextInt(), file_reader.nextInt(), file_reader.nextInt()};
                        T.B = new Banker(sys_total[0],sys_total[1],sys_total[2]);
                    }
                    else if(str.contains("process")){
                        int id = file_reader.nextInt();
                        int[] max;
                        int[] alloc;

                        Customer c = new Customer(sem,T,id);

                        str = file_reader.next();
                        if(str.contains("max")) {
                            max = new int[]{file_reader.nextInt(), file_reader.nextInt(), file_reader.nextInt()};
                            c.set_max(max[0],max[1],max[2]);
                        }

                        str = file_reader.next();
                        if(str.contains("alloc")) {
                            alloc = new int[]{file_reader.nextInt(), file_reader.nextInt(), file_reader.nextInt()};
                            c.set_alloc(alloc[0],alloc[1],alloc[2]);
                        }

                        Thread t = new Thread(c);
                        t.start();
                        customers.add(t);
                    }
                }
            }
        }catch(Exception e){
            System.out.println(e.toString());
        }

        for(Thread t : customers) {
            try{
                t.join();
            }catch (Exception e){
                System.out.println(e.toString());
            }

        }

        System.out.println("Exiting Simulation...");
    }

}
