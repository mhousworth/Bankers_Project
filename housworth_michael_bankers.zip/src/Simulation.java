import java.io.File;
import java.util.Random;
import java.util.Scanner;
import java.util.concurrent.Semaphore;
import java.util.ArrayList;

public class Simulation {

    static void start_sim_rand() {
        Semaphore sem = new Semaphore(1);
        Random rnd = new Random();
        Teller T = new Teller();

        int REC = 1 + rnd.nextInt(6);
        int[] total = new int[REC];

        for (int i = 0; i < REC; i++) { total[i] = (rnd.nextInt(15) + 5); }

        T.B = new Banker(REC, total);


        int p = (rnd.nextInt(5) + 3);

        ArrayList<Thread> customers = new ArrayList<Thread>();

        for(int i = 0; i < p; i++) {
            Thread t = new Thread(new Customer(sem,T,i));
            t.start();
            customers.add(t);
        }

        for(Thread t : customers) {
            try{
                t.join();
            }catch (Exception e){
                System.out.println(e.toString());
            }

        }

        System.out.println("Exiting Simulation...");
    }

    static void start_sim_fromfile() {
        Semaphore sem = new Semaphore(1);
        Random rnd = new Random();
        Teller T = new Teller();
        int num_rec = 3;

        ArrayList<Thread> customers = new ArrayList<Thread>();

        // src/config1.txt   src/StallingsFig6-7.txt   src/Silberschatz8-6-3-3.txt
        File f = new File("src/Silberschatz8-6-3-3.txt");

        String str = "";

        try{
            Scanner file_reader = new Scanner(f);

            if(f.exists()) {
                while(file_reader.hasNextLine()){
                    str = file_reader.next();

                    if(str.contains("num_resources")){
                        num_rec = file_reader.nextInt();
                    }
                    else if (str.contains("system_total")){
                        int[] sys_total = new int[num_rec];
                        for (int i = 0; i < num_rec; i++) { sys_total[i] = file_reader.nextInt(); }
                        T.B = new Banker(num_rec, sys_total);
                    }
                    else if(str.contains("process")){
                        int id = file_reader.nextInt();
                        int[] max;
                        int[] alloc;

                        Customer c = new Customer(sem,T,id);
                        c.max = true;

                        str = file_reader.next();
                        if(str.contains("max")) {
                            max = new int[num_rec];
                            for (int i = 0; i < num_rec; i++) { max[i] = file_reader.nextInt(); }
                            c.set_max(max);
                        }

                        str = file_reader.next();
                        if(str.contains("alloc")) {
                            alloc = new int[num_rec];
                            for (int i = 0; i < num_rec; i++) { alloc[i] = file_reader.nextInt(); }
                            c.set_alloc(alloc);
                        }

                        Thread t = new Thread(c);
                        t.start();
                        customers.add(t);
                    }
                }
                sem.acquire();
                T.print_process_table();
                sem.release();
            }
        }catch(Exception e){
            System.out.println(e.toString());
        }

        for(Thread t : customers) {
            try{
                t.join();
            }catch (Exception e){
                System.out.println(e.toString());
            }

        }

        System.out.println("Exiting Simulation...");
    }

}
