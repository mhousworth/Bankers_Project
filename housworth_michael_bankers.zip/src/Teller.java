import java.util.ArrayList;
import java.util.Scanner;

//Class handling input and output with relatively nice prompts and formatting
public class Teller {

    Scanner keyboard;
    Banker B;
    ArrayList<Integer> pid;

    Teller(){
        keyboard = new Scanner(System.in);
        B = new Banker(6, 12, 19);
        pid = new ArrayList<Integer>();
    }

    Teller(Banker b) {
        keyboard = new Scanner(System.in);
        B = b;
        pid = new ArrayList<Integer>();
    }

    //Option for a starting set of processes
    void init() {
        for (int i = 0; i < 5; i++) {
            System.out.printf("Adding process %d...\n", i);
            pid.add(i);
        }
        B.create_process(0, 7, 5, 3);
        B.create_process(1, 3, 2, 2);
        B.create_process(2, 9, 0, 2);
        B.create_process(3, 2, 2, 2);
        B.create_process(4, 4, 3, 3);
    }

    //Recreates Example posted on Titanium
    void case1() {
        //Initial allocation
        B.request(0, 0, 1, 0);
        B.request(1, 2, 0, 0);
        B.request(2, 3, 0, 2);
        B.request(3, 2, 1, 1);
        B.request(4, 0, 0, 2);

        request(0,3,1,1);
        request(4,4,2,1);
        request(3,0,1,0);
        request(0,1,2,0);
        request(2,2,0,0);
        request(4,0,1,0);
        request(1,0,1,1);
        request(2,4,0,0);
        request(2,2,0,0);
        request(2,3,0,0);
        request(0,1,3,2);
        request(0,3,3,2);
        request(3,0,0,1);
        request(0,1,0,1);
        request(1,0,2,1);
        request(1,0,2,2);
        request(2,2,0,0);
        execute(3);
        execute(4);
        request(1,0,1,2);
        request(2,3,0,0);
        request(0,1,0,0);
        request(1,0,1,0);
        request(2,1,0,0);
        request(0,0,2,0);
        request(1,1,0,0);
        execute(2);
        execute(1);
        request(0,1,0,1);
        request(0,0,1,0);
        request(0,1,0,0);
        execute(0);
    }

    void print_instruct() {
        System.out.println("Choose from the following: 1 - Add Process | 2 - Request Resource | 3 - Execute Process | 0 - Exit\n");
    }

    void print_process_table() {
        //Get System's available resources
        int[] avail = B.get_available();

        System.out.printf("Available: [%d %d %d]\n", avail[0], avail[1], avail[2]);
        System.out.println("\t\tALLOCATED\tMAXIMUM\t\tNEED");

        //For each process
        for (int i : pid) {
            //Check if process has ran and terminated
            if (B.get_process_status(i)) {
                System.out.println("\t\t-------\t\t-------\t\t-------");
            }
            else {
                //print process info: 0:alloc, 1:max, 2:need
                for (int j = 0; j < 3; j++) {
                    int[] arr = B.get_process_info(i, j);
                    System.out.printf("\t\t[%d %d %d]", arr[0], arr[1], arr[2]);
                }
                System.out.println("");
            }
        }
    }

    void create_process_prompt() {
        System.out.print("Enter id of process: ");
        int id = keyboard.nextInt();

        //If process with id already exists
        if (pid.contains(id)) {
            System.out.printf("Process with id: %d already exists", id);
            return;
        }

        System.out.println("For max resources needed to run process");
        System.out.print("Enter Resource #0: ");
        int r0 = keyboard.nextInt();
        System.out.print("Enter Resource #1: ");
        int r1 = keyboard.nextInt();
        System.out.print("Enter Resource #2: ");
        int r2 = keyboard.nextInt();

        pid.add(id);
        B.create_process(id,r0,r1,r2);
    }

    void request_prompt() {
        System.out.print("Enter id of requesting process: ");
        int id = keyboard.nextInt();

        //If process with id does not exist
        if (!pid.contains(id)){
            System.out.printf("Process with id: %d does not exist", id);
            return;
        }

        System.out.print("Enter Resource #0: ");
        int r0 = keyboard.nextInt();
        System.out.print("Enter Resource #1: ");
        int r1 = keyboard.nextInt();
        System.out.print("Enter Resource #2: ");
        int r2 = keyboard.nextInt();

        request(id, r0, r1, r2);
    }

    void request(int id, int r0, int r1, int r2) {
        int[] need = B.get_process_info(id, 2);
        System.out.printf("#P%d RQ:[%d %d %d],needs:[%d %d %d],", id, r0, r1, r2, need[0], need[1], need[2]);

        int[] avail = B.get_available();
        System.out.printf("available=[%d %d %d]", avail[0], avail[1], avail[2]);

        if(B.request(id, r0, r1, r2)) {
            int[] alloc = B.get_process_info(id, 0);
            System.out.printf("\t ---> APPROVED, #P%d now at:[%d %d %d]\n", id, alloc[0], alloc[1], alloc[2]);
            print_process_table();
        }
        else
            System.out.printf("\t ---> DENIED\n");
    }

    //Execute instruction
    void execute_prompt() {
        System.out.print("Enter id of process to Execute: ");
        int id = keyboard.nextInt();

        //If process with id does not exist
        if (!pid.contains(id)){
            System.out.printf("Process with id: %d does not exist", id);
            return;
        }

        execute(id);
    }

    void execute(int id) {
        if(B.get_process_status(id)) {
            System.out.println("Process already ran to completion.");
        }
        else {
            //Run execute, returns false if it could not run
            if(B.execute(id)) {
                System.out.printf("---------------->Process #%d has all its resources. Executing... Releasing ALL. Terminating...", id);

                //Get resources that will be released, current allocation
                int [] release = B.get_process_info(id, 0);
                B.release(id);
                //Allocation after release
                int [] alloc = B.get_process_info(id, 0);

                System.out.printf("=================Process #%d releasing:[%d %d %d], allocated:[%d %d %d]\n",
                        id, release[0], release[1], release[2], alloc[0], alloc[1], alloc[2]);
            }
            else {
                //Get resource values the process needs
                int[] need = B.get_process_info(id, 2);

                System.out.printf("Process #%d cannot execute. Requires resources: [%d %d %d]\n", id, need[0], need[1], need[2]);
            }
        }
    }

    boolean get_instruct() {
        //Check for correct input
        int input = keyboard.nextInt();

        if (input == 0) {
            System.out.println("Exiting Interactive...");
            return false;
        }
        else if (input == 1) {
            create_process_prompt();
            return true;
        }
        else if (input == 2) {
            request_prompt();
            return true;
        }
        else if (input == 3) {
            execute_prompt();
            return true;
        }
        else {
            System.out.println("Invalid Input");
            return true;
        }
    }

}