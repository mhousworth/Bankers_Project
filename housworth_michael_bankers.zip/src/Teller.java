import java.util.ArrayList;
import java.util.Scanner;

//Class handling input and output with relatively nice prompts and formatting
public class Teller {

    Scanner keyboard;
    Banker B;
    ArrayList<Integer> pid;

    Teller(){
        keyboard = new Scanner(System.in);
        B = new Banker(3, new int[]{6, 12, 19});
        pid = new ArrayList<Integer>();
    }

    Teller(Banker b) {
        keyboard = new Scanner(System.in);
        B = b;
        pid = new ArrayList<Integer>();
    }

    void print_instruct() {
        System.out.println("Choose from the following: 1 - Add Process | 2 - Request Resource | 3 - Execute Process | 0 - Exit");
    }

    void print_process_table() {
        //Get System's available resources
        int[] avail = B.get_available();

        System.out.printf("Available: [ ");
        for (int i = 0; i < B.get_RESOURCES(); i++){
            System.out.print(avail[i] + " ");
        }
        System.out.print("]\n");

        System.out.print("\t\tALLOCATED");
        for (int i = 0; i <= (B.get_RESOURCES()/3); i++) System.out.print("\t");
        System.out.print("MAXIMUM\t");
        for (int i = 0; i <= (B.get_RESOURCES()/3); i++) System.out.print("\t");
        System.out.print("NEED\n");

        //For each process
        for (int i : pid) {
            //Check if process has ran and terminated
            if (B.get_process_status(i)) {
                for(int j = 0; j < 3; j++) {
                    System.out.print("\t\t--");
                    for (int o = 0; o < B.get_RESOURCES(); o++) System.out.print("--");
                }
                System.out.println("");
            }
            else {
                //print process info: 0:alloc, 1:max, 2:need
                for (int j = 0; j < 3; j++) {
                    int[] arr = B.get_process_info(i, j);
                    System.out.printf("\t\t[ ");
                    for (int o = 0; o < arr.length; o++){
                        System.out.print(arr[o] + " ");
                    }
                    System.out.print("]");
                }
                System.out.println("");
            }
        }
    }

    void create_process_prompt() {
        System.out.print("Enter id of process: ");
        int id = keyboard.nextInt();

        //If process with id already exists
        if (pid.contains(id)) {
            System.out.printf("Process with id: %d already exists", id);
            return;
        }

        int[] max = new int[B.get_RESOURCES()];

        System.out.print("Set max resources of process, Enter: ");
        for (int i = 0; i < B.get_RESOURCES(); i++) { System.out.printf("R%d ", i); }
        System.out.println("");
        for (int i = 0; i < B.get_RESOURCES(); i++) {
            if(keyboard.hasNextInt()){
                max[i] = keyboard.nextInt();
            }
            else
                System.out.printf("INVALID INPUT: Require set of %d integers", B.get_RESOURCES());
        }

        pid.add(id);
        if(!B.create_process(id, max))
            System.out.println("INVALID INPUT: Process resources exceeds System total");
    }

    void request_prompt() {
        System.out.print("Enter id of requesting process: ");
        int id = keyboard.nextInt();

        //If process with id does not exist
        if (!pid.contains(id)){
            System.out.printf("Process with id: %d does not exist", id);
            return;
        }

        int[] req = new int[B.get_RESOURCES()];

        System.out.print("For resources request, Enter: ");
        for (int i = 0; i < B.get_RESOURCES(); i++) { System.out.printf("R%d ", i); }
        System.out.println("");
        for (int i = 0; i < B.get_RESOURCES(); i++) {
            if(keyboard.hasNextInt()){
                req[i] = keyboard.nextInt();
            }
            else
                System.out.printf("INVALID INPUT: Require set of %d integers", B.get_RESOURCES());
        }

        request(id, req);
    }

    void request(int id, int[] req) {
        System.out.printf("#P%d RQ:[ ", id);
        for (int i = 0; i < req.length; i++) {
            System.out.print(req[i] + " ");
        }

        int[] need = B.get_process_info(id, 2);
        System.out.print("],needs:[ ");
        for (int i = 0; i < need.length; i++) {
            System.out.print(need[i] + " ");
        }

        int[] avail = B.get_available();
        System.out.print("],available=[ ");
        for (int i = 0; i < avail.length; i++) {
            System.out.print(avail[i] + " ");
        }
        System.out.print("]");

        if(B.request(id, req)) {
            int[] alloc = B.get_process_info(id, 0);
            System.out.printf("\t ---> APPROVED, #P%d now at:[ ", id);
            for (int i = 0; i < alloc.length; i++) {
                System.out.print(alloc[i] + " ");
            }
            System.out.print("]\n");
            print_process_table();
        }
        else
            System.out.printf("\t ---> DENIED\n");
    }

    //Execute instruction
    void execute_prompt() {
        System.out.print("Enter id of process to Execute: ");
        int id = keyboard.nextInt();

        //If process with id does not exist
        if (!pid.contains(id)){
            System.out.printf("Process with id: %d does not exist", id);
            return;
        }

        execute(id);
    }

    void execute(int id) {
        if(B.get_process_status(id)) {
            System.out.println("Process already ran to completion.");
        }
        else {
            //Run execute, returns false if it could not run
            if(B.execute(id)) {
                System.out.printf("---------------->Process #%d has all its resources. Executing... Releasing ALL. Terminating...\n", id);

                //Get resources that will be released, current allocation
                int [] release = B.get_process_info(id, 0);
                B.release(id);
                //Allocation after release
                int [] alloc = B.get_process_info(id, 0);

                System.out.printf("=================Process #%d releasing:[ ", id);
                for (int i = 0; i < release.length; i++) { System.out.print(release[i] + " "); }
                System.out.print("}, allocated:[ ");
                for (int i = 0; i < alloc.length; i++) { System.out.print(alloc[i] + " "); }
                System.out.print("]\n");
            }
            else {
                //Get resource values the process needs
                int[] need = B.get_process_info(id, 2);

                System.out.printf("Process #%d cannot execute. Requires resources: [ ", id);
                for (int i = 0; i < need.length; i++) { System.out.print(need[i] + " "); }
                System.out.print("]\n");
            }
        }
    }

    boolean get_instruct() {
        //Check for correct input
        int input = keyboard.nextInt();

        if (input == 0) {
            System.out.println("Exiting Interactive...");
            return false;
        }
        else if (input == 1) {
            create_process_prompt();
            return true;
        }
        else if (input == 2) {
            request_prompt();
            return true;
        }
        else if (input == 3) {
            execute_prompt();
            return true;
        }
        else {
            System.out.println("Invalid Input");
            return true;
        }
    }

}